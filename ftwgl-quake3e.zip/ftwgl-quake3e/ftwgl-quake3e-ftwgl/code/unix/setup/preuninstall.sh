#!/bin/sh
rm -f COPYING
rmdir --ignore-fail-on-non-empty demoq3 missionpack >& /dev/null
